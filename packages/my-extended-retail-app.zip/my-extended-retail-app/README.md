# Steps

1. `npm i full-icu@^1.3.1 pwa-kit-dev cross-env`
